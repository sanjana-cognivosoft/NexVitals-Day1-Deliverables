NEXVITALS DAY 1 – GITHUB UPLOAD PACKAGE

1. Read README.md first.
2. Confirm the destination is the company-approved PRIVATE repository.
3. Upload the contents of this folder, preserving the directory structure.
4. Do not publish or share these confidential files publicly.
5. GitHub upload, commit ID and Trello updates remain to be completed by the user in approved workspaces.

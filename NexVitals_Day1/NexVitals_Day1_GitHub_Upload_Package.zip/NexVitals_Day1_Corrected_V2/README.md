# NexVitals – Day 1 Deliverables

> **Confidential – for authorized company use only.**
> This package contains project documentation and design references. Upload it only to the company-approved **private** GitHub repository and approved workspaces. Do not make it public or share it externally.

## Package contents

| Folder | Contents |
|---|---|
| `01_Project_Understanding/` | Project understanding document |
| `02_Workflow_Diagrams/` | Patient, Admin and Staff workflow diagrams; workflow notes and exception handling |
| `03_Application_Requirements/` | Application pages and requirements document |
| `04_UI_UX_Design/` | Task 4 UI/UX design report and Figma prototype link |
| `04_Daily_Report/` | Day 1 progress report files from the earlier documentation package |

## Figma prototype

https://www.figma.com/design/rTQ679V6Q6VjA6KFfV272w/NexVitals-%E2%80%93-Initial-UI-UX-Design?node-id=0-1&t=zXBjfJKDS2vZyON8-1

## Upload instructions

1. Confirm this is the company-approved private repository and that you have permission to upload confidential NexVitals materials.
2. Extract this ZIP on your laptop.
3. In the repository, select **Add file → Upload files**.
4. Open the extracted `NexVitals_Day1_Corrected_V2` folder and upload its contents (including folders). If the browser does not preserve folders when selecting files, drag the entire folder contents into the upload area or use Git locally.
5. Review the file list and confirm repository visibility is **Private** before committing.
6. Use commit message: `Add Day 1 documentation and UI UX deliverables`.
7. After committing, copy the repository link and latest commit ID for the updated daily report.

## Status and limitations

- The documentation and four-screen Figma prototype have been prepared.
- GitHub upload/commit and Trello updates are **not performed by this package**; they must be completed in the approved company workspaces.
- Figma access and prototype navigation should be checked by the authorized reviewer.
- Authentication, registration rules, supported languages, privacy/consent wording and other policy-dependent details remain subject to company confirmation.
- Do not begin full application development until workflows and UI/UX designs are reviewed and approved.
